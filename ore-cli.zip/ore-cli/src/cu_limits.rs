pub const CU_LIMIT_UPGRADE: u32 = 20_000;
pub const CU_LIMIT_CLAIM: u32 = 32_000;
pub const _CU_LIMIT_RESET: u32 = 12_200;
pub const _CU_LIMIT_MINE: u32 = 3200;
